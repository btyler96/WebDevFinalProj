"use strict";

var greenLight = document.getElementById("greenLight");
greenLight.style.visibility = "hidden";

var redLight = document.getElementById("redLight");

var plane1 = document.getElementById("plane1");

var plane2 = document.getElementById("plane2");

var plane3 = document.getElementById("plane3");

var pos1 = 0;
var pos2 = 0;
var pos3 = 0;
var interval = 0;


function startRace()
{
    redLight.style.visibility = "hidden";
    greenLight.style.visibility = "visible";
    
    interval = setInterval(race, 500);
    function race() 
    {
        var newPos1 = (Math.random() * 100) + pos1;
        var newPos2 = (Math.random() * 100) + pos2;
        var newPos3 = (Math.random() * 100) + pos3;

        plane1.style.marginLeft = newPos1 + "px";
        plane2.style.marginLeft = newPos2 + "px";
        plane3.style.marginLeft = newPos3 + "px";

        pos1 = newPos1;
        pos2 = newPos2;
        pos3 = newPos3;
       
        var width = screen.width;

        if (pos1 >= width - 355)
        {
            window.alert("Plane 1 has won!");             
            reset();
        }
        else if(pos2 >= width - 355)
        {
            window.alert("Plane 2 has won!");            
            reset();
        }
        else if(pos3 >= width - 355)
        {
            window.alert("Plane 3 has won!");            
            reset();
        }
    } 
}


function reset()
{
    pos1 = 0;
    pos2 = 0;
    pos3 = 0;
    plane1.style.marginLeft = 0;
    plane2.style.marginLeft = 0;
    plane3.style.marginLeft = 0;
    redLight.style.visibility = "visible";
    greenLight.style.visibility = "hidden";
    clearInterval(interval);
}